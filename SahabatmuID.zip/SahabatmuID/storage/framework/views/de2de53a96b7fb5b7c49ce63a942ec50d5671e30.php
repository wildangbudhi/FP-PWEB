
<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby= "<?php echo $__env->yieldContent('id'); ?>ModalLabel" id="<?php echo $__env->yieldContent('id'); ?>Modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4><?php echo $__env->yieldContent('title'); ?></h4>
                <button type="button" name="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</div>